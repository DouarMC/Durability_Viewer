import { world, system } from "@minecraft/server";
system.runInterval(() => {
    const players = world.getAllPlayers();
    players.forEach((player) => {
        const invComp = player.getComponent("inventory");
        const container = invComp.container;
        for (let i = 0; i < container.size; i++) {
            const item = container.getItem(i);
            if (!item || !item.hasComponent("durability"))
                continue;
            const durabilityComp = item.getComponent("durability");
            const durability = durabilityComp.maxDurability - durabilityComp.damage;
            container.getSlot(i).setLore(["§fDurabilité", `§e${durability}`]);
        }
        ;
        const equippableComp = player.getComponent("equippable");
        for (const slot of Utilities.equipmentSlots) {
            const item = equippableComp.getEquipment(slot);
            if (!item || !item.hasComponent("durability"))
                continue;
            const durabilityComp = item.getComponent("durability");
            const durability = durabilityComp.maxDurability - durabilityComp.damage;
            equippableComp.getEquipmentSlot(slot).setLore(["§fDurabilité", `§e${durability}`]);
        }
        ;
    });
});
class Utilities {
}
Utilities.equipmentSlots = ["Chest", "Feet", "Head", "Legs", "Offhand"];
;
