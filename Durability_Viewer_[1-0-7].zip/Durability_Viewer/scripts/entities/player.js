import { world, system, EntityComponentTypes, ItemComponentTypes } from "@minecraft/server";
// Interval qui affiche dans le lore de chaque Item du joueur sa durabilité.
system.runInterval(() => {
    const players = world.getAllPlayers(); // Récupère tous les joueurs
    for (const player of players) { // Pour chaque joueur
        const playerInventoryComponent = player.getComponent(EntityComponentTypes.Inventory); // Récupère l'inventaire du joueur
        const playerContainer = playerInventoryComponent.container; // Récupère le container de l'inventaire du joueur
        for (let i = 0; i < playerContainer.size; i++) { // Pour chaque slot de l'inventaire
            const playerInventorySlot = playerContainer.getSlot(i); // Récupère le slot
            const itemStack = playerInventorySlot.getItem(); // Récupère l'itemStack du slot
            if (itemStack === undefined || itemStack.hasComponent(ItemComponentTypes.Durability) === false)
                continue; // Si l'itemStack est undefined ou n'a pas de composant Durability, on passe au slot suivant
            const itemDurabilityComponent = itemStack.getComponent(ItemComponentTypes.Durability); // Récupère le composant Durability de l'itemStack
            const currentDurability = itemDurabilityComponent.maxDurability - itemDurabilityComponent.damage; // Calcule la durabilité restante
            playerInventorySlot.setLore(["Durability :", `§e${currentDurability}`]); // Met à jour le lore du slot
        }
        ;
        const playerEquippableComponent = player.getComponent(EntityComponentTypes.Equippable); // Récupère le composant Equippable du joueur
        for (const equippableSlot of ["Chest", "Feet", "Head", "Legs", "Offhand"]) { // Pour chaque slot équipable
            const playerEquippableSlot = playerEquippableComponent.getEquipmentSlot(equippableSlot); // Récupère le slot équipable
            const itemStack = playerEquippableSlot.getItem(); // Récupère l'itemStack du slot
            if (itemStack === undefined || itemStack.hasComponent(ItemComponentTypes.Durability) === false)
                continue; // Si l'itemStack est undefined ou n'a pas de composant Durability, on passe au slot suivant
            const itemDurabilityComponent = itemStack.getComponent(ItemComponentTypes.Durability); // Récupère le composant Durability de l'itemStack
            const currentDurability = itemDurabilityComponent.maxDurability - itemDurabilityComponent.damage; // Calcule la durabilité restante
            playerEquippableSlot.setLore(["Durability :", `§e${currentDurability}`]); // Met à jour le lore du slot
        }
        ;
    }
    ;
});
